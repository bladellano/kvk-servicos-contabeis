<?php if(!class_exists('Rain\Tpl')){exit;}?><div class="header-page"></div>
<div class="container">
    <p></p>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Empresas do Grupo</li>
        </ol>
    </nav>
    <h1>Empresas do Grupo</h1>

    <ul class="list-empresas-do-grupo">
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#apmelocosta">A P DE MELO COSTA</button>
            <div id="apmelocosta" class="collapse">
                <small>Nome Fantasia:</small><br/> DER E ANA COMERCIO E VARIEDADES 
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#acdasilva">A C DA SILVA </button>
            <div id="acdasilva" class="collapse">
                <small>Nome Fantasia:</small><br/> CONSTEX 
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#adorfsilveira">A DO R F SILVEIRA</button>
            <div id="adorfsilveira" class="collapse">
                <small>Nome Fantasia:</small><br/> PLAY-CELL  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#apdemfilial">A PINHEIRO DE OLIVEIRA ME FILIAL</button>
            <div id="apdemfilial" class="collapse">
                <small>Nome Fantasia:</small><br/> CONFECÇÕES CEARÁ  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#apdmatriz">A PINHEIRO DE OLIVEIRA ME MATRIZ</button>
            <div id="apdmatriz" class="collapse">
                <small>Nome Fantasia:</small><br/> CONFECÇÕES CEARÁ 
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#bcep">BIOMARKET COMERCIO EIRELI EPP</button>
            <div id="bcep" class="collapse">
                <small>Nome Fantasia:</small><br/> BIOMARKET  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#cabacomer">CABANAGEM COMERCIO LTDA ME</button>
            <div id="cabacomer" class="collapse">
                <small>Nome Fantasia:</small><br/> ESTÂNCIA CABANAGEM  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#clickacaib">CLICK AÇAI BRASIL COMÉRCIO DE AÇAÍ LTDA</button>
            <div id="clickacaib" class="collapse">
                <small>Nome Fantasia:</small><br/> CLICK AÇAI DISTRIBUIDOR BRASIL  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#clickacailtda">CLICK AÇAI LTDA ME </button>
            <div id="clickacailtda" class="collapse">
                <small>Nome Fantasia:</small><br/> CLICK AÇAI  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#cliacaifi">CLICK AÇAÍ TECNOLOGIA COMÉRCIO DE AÇAÍ FILIAL</button>
            <div id="cliacaifi" class="collapse">
                <small>Nome Fantasia:</small><br/> CLICK AÇAI TECNOLOGIA   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#ceeletro">CEARÁ ELETRONICA</button>
            <div id="ceeletro" class="collapse">
                <small>Nome Fantasia:</small><br/> CEARÁ ELETRONICA   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#coopprinc">COOPERATIVA PRINCIPE DA PAZ</button>
            <div id="coopprinc" class="collapse">
                <small>Nome Fantasia:</small><br/> COOEPP  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#cagomes">C A GOMES</button>
            <div id="cagomes" class="collapse">
                <small>Nome Fantasia:</small><br/> D DEZ  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#etpanieconf">E & T PANIFICACAO E CONFEITARIA LTDA</button>
            <div id="etpanieconf" class="collapse">
                <small>Nome Fantasia:</small><br/> PANIFICADORA E CONFEITARIA SANTA TEREZINHA   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#fdbatista">F D BATISTA NETO ME</button>
            <div id="fdbatista" class="collapse">
                <small>Nome Fantasia:</small><br/> ELETROPISO MATERIAIS DE CONSTRUÇÃO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#fedesisltda">FEDERAL SISTEMA LTDA ME</button>
            <div id="fedesisltda" class="collapse">
                <small>Nome Fantasia:</small><br/> FEDERAL  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#gapmar">G A P MARMORES GRANITOS LTDA ME</button>
            <div id="gapmar" class="collapse">
                <small>Nome Fantasia:</small><br/> G A P MARMORES E GRANITOS  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#hmcomercioltda">H M COMERCIO LTDA ME </button>
            <div id="hmcomercioltda" class="collapse">
                <small>Nome Fantasia:</small><br/> INSTITUTO CAXINAUA LINAGUAGENS E CÓDIGOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jbotelho">J BOTELHO NUNES & CIA LTDA</button>
            <div id="jbotelho" class="collapse">
                <small>Nome Fantasia:</small><br/> WINNER  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jdejesus">J DE JESUS S FERREIRA</button>
            <div id="jdejesus" class="collapse">
                <small>Nome Fantasia:</small><br/> JERUSALÉM MATERIAIS DE CONSTRUÇÃO  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jsferreira">J F FERREIRA EIRELI - ME</button>
            <div id="jsferreira" class="collapse">
                <small>Nome Fantasia:</small><br/> NOSSA CASA MATERIAIS DE CONSTRUÇÃO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jldossantos">J L DOS SANTOS EPP</button>
            <div id="jldossantos" class="collapse">
                <small>Nome Fantasia:</small><br/> BKM MEDICAL  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jlimada">J LIMA DA CONCEICAO - ME</button>
            <div id="jlimada" class="collapse">
                <small>Nome Fantasia:</small><br/> J S MODA FEMININA   
            </div> 
        </li>

        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jpcorrea">J P CORREA LTDA ME</button>
            <div id="jpcorrea" class="collapse">
                <small>Nome Fantasia:</small><br/> ESTÂNCIA CORREA  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jpontesoliveira">J PONTES DE OLIVEIRA EIRELI ME</button>
            <div id="jpontesoliveira" class="collapse">
                <small>Nome Fantasia:</small><br/> CHURRASCARIA DO JOEL   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jrobertobo">J ROBERTO BORGES E CIA LTDA ME</button>
            <div id="jrobertobo" class="collapse">
                <small>Nome Fantasia:</small><br/> J P CARAMELOS   
            </div> 
        </li>        
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jbeireli">JOAO BATISTA EIRELI LTDA ME</button>
            <div id="jbeireli" class="collapse">
                <small>Nome Fantasia:</small><br/> BELEM MATERIAIS DE CONSTRUÇÃO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jpaleixo">JOÃO P ALEIXO ME</button>
            <div id="jpaleixo" class="collapse">
                <small>Nome Fantasia:</small><br/> AUTO ELÉTRICA J P  
            </div> 
        </li>

        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#lldeoliveira">L L DE OLIVEIRA ME - FILIAL</button>
            <div id="lldeoliveira" class="collapse">
                <small>Nome Fantasia:</small><br/> CONFECÇÕES CEARÁ   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#lldeoliveira">L L DE OLIVEIRA ME - MATRIZ</button>
            <div id="lldeoliveira" class="collapse">
                <small>Nome Fantasia:</small><br/> CONFECÇÕES BETEL   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#lugirl">LUZIETE L DE OLIVEIRA E CIA LTDA (FILIAL)</button>
            <div id="lugirl" class="collapse">
                <small>Nome Fantasia:</small><br/> ESTILOSA GIRL  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#lumaranhao">LUZIETE L DE OLIVEIRA E CIA LTDA (MATRIZ)</button>
            <div id="lumaranhao" class="collapse">
                <small>Nome Fantasia:</small><br/> CONFECÇÕES MARANHÃO   
            </div> 
        </li>

        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#mabdacunha">M A B DA CUNHA ME</button>
            <div id="mabdacunha" class="collapse">
                <small>Nome Fantasia:</small><br/> AUTOTEC   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#mcralimentos">M C R COMERCIO DE ALIMENTOS LTDA ME</button>
            <div id="mcralimentos" class="collapse">
                <small>Nome Fantasia:</small><br/> *****  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#nonacruz">NONATO E CRUZ LTDA ME</button>
            <div id="nonacruz" class="collapse">
                <small>Nome Fantasia:</small><br/> CENTRO EDUCACIONAL DEDINHO MÁGICO  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#ocydacosta">OCY G DA COSTA EIRELI </button>
            <div id="ocydacosta" class="collapse">
                <small>Nome Fantasia:</small><br/> COMERCIAL DEUS É FIEL   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#olimadacon">O LIMA DA CONCEICAO EIRELI ME</button>
            <div id="olimadacon" class="collapse">
                <small>Nome Fantasia:</small><br/> EL SHADAY ARMARINHO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#reparrec">REPAR RECICLAGEM INDUSTRIAL</button>
            <div id="reparrec" class="collapse">
                <small>Nome Fantasia:</small><br/> REPAR RECICLAGEM DO PARÁ   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#shallomt">SHALLOM TRANSPORTES </button>
            <div id="shallomt" class="collapse">
                <small>Nome Fantasia:</small><br/> SHALLOM TURISMO E AUTOPEÇAS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#tmmotos">T M DE BRITO EIRELI</button>
            <div id="tmmotos" class="collapse">
                <small>Nome Fantasia:</small><br/> BARBA MOTOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#urbfsilva">URBANO F SILVA ME</button>
            <div id="urbfsilva" class="collapse">
                <small>Nome Fantasia:</small><br/> ESTANCIA APOCALIPSO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#vfreitasrod">V FREITAS RODRIGUES JUNIOR & CIA LTDA</button>
            <div id="vfreitasrod" class="collapse">
                <small>Nome Fantasia:</small><br/> VIDA- CENTRO DE RECUPERAÇÃO PARA DEPENDENTES QUIMICOS   
            </div> 
        </li>

        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#vmholiveira">V M H OLIVEIRA EIRELI ME</button>
            <div id="vmholiveira" class="collapse">
                <small>Nome Fantasia:</small><br/> M & S REPRESENTAÇÕES   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#viamotos">W DE SOUZA COSTA ME </button>
            <div id="viamotos" class="collapse">
                <small>Nome Fantasia:</small><br/> VIA MOTOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#walberal">WALBER ALMEIDA DE SOUZA EIRELI </button>
            <div id="walberal" class="collapse">
                <small>Nome Fantasia:</small><br/> CENTRO EDUC. DE ENSINO FUNDAMENTAL CRESCENDO COM JESUS  
            </div> 
        </li>

        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#ailtonl">AILTON LEANDRO CASTRO PEREIRA  </button>
            <div id="ailtonl" class="collapse">
                <small>Nome Fantasia:</small><br/> FIXACAR CARROS AUTOMOTIVOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#almired">ALMIR EDSON ALMEIDA E SILVA</button>
            <div id="almired" class="collapse">
                <small>Nome Fantasia:</small><br/> ****  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#arlindacris">ARLINDA CRISTIANE GUALBERTO </button>
            <div id="arlindacris" class="collapse">
                <small>Nome Fantasia:</small><br/> A C MKT DE SERVIÇOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#brunos">BRUNO ROSÁRIO SE SOUZA</button>
            <div id="brunos" class="collapse">
                <small>Nome Fantasia:</small><br/> B R SOUZA SERVIÇOS AUTOMOTIVOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#deivau">DEIVISON AUGUSTO GUIMARAES DA CUNHA</button>
            <div id="deivau" class="collapse">
                <small>Nome Fantasia:</small><br/> MECTRON ESTÉTICA AUTOMOTICA   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#joanagab">JOANA GABRIELA FERREIRA BATISTA</button>
            <div id="joanagab" class="collapse">
                <small>Nome Fantasia:</small><br/> BIG LOBO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jonasbar">JONAS BARROS DE SOUZA</button>
            <div id="jonasbar" class="collapse">
                <small>Nome Fantasia:</small><br/> JONAS SOUZA  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#lailsonma">LAILSON MARCIO SILVA ALVES</button>
            <div id="lailsonma" class="collapse">
                <small>Nome Fantasia:</small><br/> JAPACAR SERVIÇO AUTOMOTIVO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#lygiamaria">LYGIA MARIA DA CUNHA DA SILVA</button>
            <div id="lygiamaria" class="collapse">
                <small>Nome Fantasia:</small><br/> BIG LOBO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#lindomarde">LNDOMAR DE SOUZA</button>
            <div id="lindomarde" class="collapse">
                <small>Nome Fantasia:</small><br/> SOARES MOTOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#moacirbar">MOACIR BARBOSA</button>
            <div id="moacirbar" class="collapse">
                <small>Nome Fantasia:</small><br/> M B OLIVEIRA MANUTENÇÃO   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#jonasdesou">JONAS DE SOUZA MARISCOS</button>
            <div id="jonasdesou" class="collapse">
                <small>Nome Fantasia:</small><br/> SOUZA MARISCOS  
            </div> 
        </li>

        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#juarezdeso">JUAREZ DE SOUZA PIRES</button>
            <div id="juarezdeso" class="collapse">
                <small>Nome Fantasia:</small><br/> JUAREZ SERIVIÇOS AUTOMOTIVOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#rafarod">RAFAEL RODRIGUES DA CUNHA</button>
            <div id="rafarod" class="collapse">
                <small>Nome Fantasia:</small><br/> TAIOBA SERVIÇO AUTOMOTIVO  
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#rapharod">RAPHAEL RODRIGUES DA SILVA</button>
            <div id="rapharod" class="collapse">
                <small>Nome Fantasia:</small><br/> RAPHAEL MOTOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#ruafern">RUAN FERNANDO MATOS DE ASSUNÇÃO</button>
            <div id="ruafern" class="collapse">
                <small>Nome Fantasia:</small><br/> RUAN MOTOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#tiagomaia">TIAGO MAIA DA SILVA</button>
            <div id="tiagomaia" class="collapse">
                <small>Nome Fantasia:</small><br/> TIAGO MOTOS   
            </div> 
        </li>
        <li>
            <button class="btn btn-default btn-block" data-toggle="collapse" data-target="#vitorfa">VITOR FARIAS DA SILVA</button>
            <div id="vitorfa" class="collapse">
                <small>Nome Fantasia:</small><br/> J P MOTOS   
            </div> 
        </li>
    </ul>
</div>