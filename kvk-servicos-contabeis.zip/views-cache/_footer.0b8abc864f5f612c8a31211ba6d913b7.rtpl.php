<?php if(!class_exists('Rain\Tpl')){exit;}?><p id="back-top">
	<a href="#top"><i class="fa fa-angle-up"></i></a>
</p>
<footer>
	<div class="container text-center">
		<p>Copyright © <?php echo YEAR; ?> - Todos os Direitos Reservados à KVK SERVIÇOS CONTÁBEIS</p>
	</div>
</footer>
<!-- Bootstrap core JavaScript
			================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script src="http://mozthemes.com/demo/lattes/js/jquery.appear.js"></script>

<!--Lib para gerar a contagem de números-->
<script src="/res/site/js/bootstrap.min.js"></script>
<script src="/res/site/js/owl.carousel.min.js"></script>
<script src="/res/site/js/cbpAnimatedHeader.js"></script>
<script src="/res/site/js/theme-scripts.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="/res/site/js/ie10-viewport-bug-workaround.js"></script>
</body>

</html>